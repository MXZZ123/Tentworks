using Tentworks.Parts;

namespace Tentworks.Fluid
{
    /// <summary>Undirected connection between two ports / nodes.</summary>
    public class FluidEdge
    {
        public FluidNode A;
        public FluidNode B;
        public Port PortA;
        public Port PortB;

        public FluidEdge(FluidNode a, FluidNode b, Port portA, Port portB)
        {
            A = a;
            B = b;
            PortA = portA;
            PortB = portB;
        }

        public FluidNode Other(FluidNode n) => n == A ? B : A;
    }
}
