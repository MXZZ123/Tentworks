using Tentworks.Parts;

namespace Tentworks.Fluid
{
    /// <summary>A node in the propellant graph, wrapping a PartInstance.</summary>
    public class FluidNode
    {
        public PartInstance Part;
        public int Id;

        public FluidNode(int id, PartInstance part)
        {
            Id = id;
            Part = part;
        }

        public bool AllowsFlow
        {
            get
            {
                if (Part == null) return false;
                if (Part.IsValve) return Part.ValveOpen;
                return true;
            }
        }
    }
}
