using System.Collections.Generic;
using Tentworks.Parts;
using UnityEngine;

namespace Tentworks.Fluid
{
    /// <summary>
    /// Graph of placed parts connected by propellant ports.
    /// Used to decide whether a thruster has an open tank→valve→thruster path.
    /// </summary>
    public class FluidGraph
    {
        readonly List<FluidNode> _nodes = new List<FluidNode>();
        readonly List<FluidEdge> _edges = new List<FluidEdge>();
        readonly Dictionary<PartInstance, FluidNode> _byPart = new Dictionary<PartInstance, FluidNode>();
        int _nextId;

        public IReadOnlyList<FluidNode> Nodes => _nodes;
        public IReadOnlyList<FluidEdge> Edges => _edges;

        public FluidNode AddPart(PartInstance part)
        {
            if (part == null) return null;
            if (_byPart.TryGetValue(part, out var existing)) return existing;

            var node = new FluidNode(_nextId++, part);
            _nodes.Add(node);
            _byPart[part] = node;
            return node;
        }

        public void RemovePart(PartInstance part)
        {
            if (part == null || !_byPart.TryGetValue(part, out var node)) return;

            for (int i = _edges.Count - 1; i >= 0; i--)
            {
                var e = _edges[i];
                if (e.A == node || e.B == node)
                {
                    e.PortA?.Disconnect();
                    _edges.RemoveAt(i);
                }
            }

            _nodes.Remove(node);
            _byPart.Remove(part);
        }

        public bool ConnectPorts(Port a, Port b)
        {
            if (a == null || b == null || a == b) return false;
            if (a.Owner == b.Owner) return false;
            if (a.IsConnected || b.IsConnected) return false;

            var nodeA = AddPart(a.Owner);
            var nodeB = AddPart(b.Owner);
            if (nodeA == null || nodeB == null) return false;

            a.Connect(b);
            _edges.Add(new FluidEdge(nodeA, nodeB, a, b));
            return true;
        }

        public void DisconnectPort(Port port)
        {
            if (port == null) return;
            for (int i = _edges.Count - 1; i >= 0; i--)
            {
                var e = _edges[i];
                if (e.PortA == port || e.PortB == port)
                {
                    e.PortA.Disconnect();
                    _edges.RemoveAt(i);
                }
            }
        }

        /// <summary>
        /// BFS: is there an open path from any tank with mass to this thruster,
        /// through open valves (closed valves block)?
        /// </summary>
        public bool HasOpenPathToThruster(PartInstance thruster, out PartInstance sourceTank)
        {
            sourceTank = null;
            if (thruster == null || !thruster.IsThruster) return false;
            if (!_byPart.TryGetValue(thruster, out var start)) return false;

            var visited = new HashSet<int>();
            var queue = new Queue<FluidNode>();
            queue.Enqueue(start);
            visited.Add(start.Id);

            while (queue.Count > 0)
            {
                var n = queue.Dequeue();
                if (n != start && !n.AllowsFlow)
                    continue;

                if (n.Part != null && n.Part.IsTank && n.Part.CurrentMassKg > 0.01f)
                {
                    sourceTank = n.Part;
                    return true;
                }

                foreach (var e in _edges)
                {
                    if (e.A != n && e.B != n) continue;
                    var other = e.Other(n);
                    if (other == null || visited.Contains(other.Id)) continue;

                    // Entering a closed valve blocks further traversal FROM that valve
                    // (we still enqueue to check tank-on-other-side only if valve open)
                    if (other.Part != null && other.Part.IsValve && !other.Part.ValveOpen)
                    {
                        visited.Add(other.Id);
                        continue;
                    }

                    visited.Add(other.Id);
                    queue.Enqueue(other);
                }
            }

            return false;
        }

        /// <summary>All thrusters that currently have an open fueled path.</summary>
        public List<(PartInstance thruster, PartInstance tank)> GetFiringCandidates()
        {
            var list = new List<(PartInstance, PartInstance)>();
            foreach (var node in _nodes)
            {
                if (node.Part == null || !node.Part.IsThruster) continue;
                if (HasOpenPathToThruster(node.Part, out var tank))
                    list.Add((node.Part, tank));
            }
            return list;
        }

        public void Clear()
        {
            foreach (var e in _edges)
                e.PortA?.Disconnect();
            _edges.Clear();
            _nodes.Clear();
            _byPart.Clear();
            _nextId = 0;
        }
    }
}
