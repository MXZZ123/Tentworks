using Tentworks.Build;
using Tentworks.Parts;
using Tentworks.UI;
using UnityEngine;

namespace Tentworks.Simulation
{
    /// <summary>
    /// Each frame (while Space held / fire active): if tank→valve→thruster path is open,
    /// show thrust visual and deplete tank mass.
    /// </summary>
    public class SimulationTicker : MonoBehaviour
    {
        BuildController _build;
        HintUI _hints;
        bool _firing;
        float _statusTimer;

        public void Initialize(BuildController build, HintUI hints)
        {
            _build = build;
            _hints = hints;
        }

        void Update()
        {
            if (_build == null) return;

            _firing = Input.GetKey(KeyCode.Space);

            // Clear all thruster visuals first
            foreach (var part in _build.PlacedParts)
            {
                if (part != null && part.IsThruster)
                    part.SetThrustVisual(false);
            }

            if (!_firing) return;

            var candidates = _build.Graph.GetFiringCandidates();
            if (candidates.Count == 0)
            {
                _statusTimer -= Time.deltaTime;
                if (_statusTimer <= 0f)
                {
                    _statusTimer = 1.2f;
                    _hints?.SetHint("No open path Tank → Valve → Thruster with fuel. Open valves & connect ports.");
                }
                return;
            }

            float dt = Time.deltaTime;
            foreach (var (thruster, tank) in candidates)
            {
                float rate = thruster.Definition != null && thruster.Definition.BurnRateKgPerSec > 0f
                    ? thruster.Definition.BurnRateKgPerSec
                    : 8f;

                float burn = rate * dt;
                if (tank.CurrentMassKg < burn)
                    burn = tank.CurrentMassKg;

                tank.CurrentMassKg -= burn;
                if (tank.CurrentMassKg < 0f) tank.CurrentMassKg = 0f;

                thruster.SetThrustVisual(tank.CurrentMassKg > 0.01f);

                _statusTimer -= dt;
                if (_statusTimer <= 0f)
                {
                    _statusTimer = 0.4f;
                    _hints?.SetHint(
                        $"FIRING {thruster.name} — tank '{tank.name}' mass: {tank.CurrentMassKg:F1} kg");
                }
            }
        }
    }
}
