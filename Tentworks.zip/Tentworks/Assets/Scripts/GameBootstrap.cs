using System.Collections.Generic;
using Tentworks.Build;
using Tentworks.Facilities;
using Tentworks.Parts;
using Tentworks.Simulation;
using Tentworks.UI;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Tentworks
{
    /// <summary>
    /// Runtime bootstrap: builds yard, tent, lighting, camera, UI, part defs, controllers at Play.
    /// Attach to any empty GameObject in an empty scene and press Play.
    /// </summary>
    public class GameBootstrap : MonoBehaviour
    {
        [Header("Optional overrides — leave empty for defaults")]
        public bool AutoBootstrapOnPlay = true;

        BuildController _build;
        HintUI _hints;

        void Start()
        {
            if (AutoBootstrapOnPlay)
                Bootstrap();
        }

        [ContextMenu("Bootstrap Now")]
        public void Bootstrap()
        {
            // Avoid double-init if scene already has content from a previous run in edit mode
            if (GameObject.Find("TentworksRoot") != null)
            {
                Debug.LogWarning("[Tentworks] TentworksRoot already exists — skipping bootstrap.");
                return;
            }

            var root = new GameObject("TentworksRoot");

            EnsureEventSystem();
            var cam = EnsureCamera(root.transform);
            BuildLighting(root.transform);
            BuildYard(root.transform);
            TentFacility.Spawn(root.transform, new Vector3(6f, 0f, 4f));

            var partsRoot = new GameObject("Parts").transform;
            partsRoot.SetParent(root.transform, false);

            var palette = CreateDemoPartDefinitions();
            var canvas = CreateCanvas(root.transform);
            _hints = HintUI.Create(canvas.transform);

            _build = root.AddComponent<BuildController>();
            _build.Initialize(cam, partsRoot, palette, _hints);

            PartPaletteUI.Create(canvas.transform, _build);

            var sim = root.AddComponent<SimulationTicker>();
            sim.Initialize(_build, _hints);

            _build.ModeChanged += () =>
            {
                _hints.SetMode($"Mode: {_build.Mode} | Part: {(_build.SelectedDefinition != null ? _build.SelectedDefinition.DisplayName : "-")}");
            };
            _hints.SetMode($"Mode: {_build.Mode} | Part: {_build.SelectedDefinition.DisplayName}");

            Debug.Log("[Tentworks] Slice 1 bootstrap complete. Place Tank → Valve → Thruster, connect ports, open valve, hold Space.");
        }

        static void EnsureEventSystem()
        {
#if UNITY_2023_1_OR_NEWER
            if (Object.FindFirstObjectByType<EventSystem>() != null) return;
#else
            if (Object.FindObjectOfType<EventSystem>() != null) return;
#endif
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();
        }

        static Camera EnsureCamera(Transform root)
        {
            Camera cam = Camera.main;
            if (cam == null)
            {
                var go = new GameObject("Main Camera");
                go.tag = "MainCamera";
                cam = go.AddComponent<Camera>();
                go.AddComponent<AudioListener>();
            }

            cam.transform.SetParent(root, true);
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.45f, 0.65f, 0.9f);
            cam.nearClipPlane = 0.1f;
            cam.farClipPlane = 200f;

            var orbit = cam.GetComponent<OrbitCamera>();
            if (orbit == null) orbit = cam.gameObject.AddComponent<OrbitCamera>();
            orbit.Initialize(new Vector3(0f, 0f, 0f));
            return cam;
        }

        static void BuildLighting(Transform root)
        {
            // Directional sun
            var lightGo = new GameObject("Sun");
            lightGo.transform.SetParent(root, false);
            lightGo.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            var light = lightGo.AddComponent<Light>();
            light.type = LightType.Directional;
            light.color = new Color(1f, 0.96f, 0.9f);
            light.intensity = 1.1f;
            light.shadows = LightShadows.Soft;

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.45f, 0.48f, 0.55f);
        }

        static void BuildYard(Transform root)
        {
            var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "DirtYard";
            ground.tag = "Ground";
            ground.transform.SetParent(root, false);
            ground.transform.position = Vector3.zero;
            ground.transform.localScale = new Vector3(4f, 1f, 4f); // 40x40m

            var r = ground.GetComponent<Renderer>();
            if (r != null)
            {
                r.material = new Material(Shader.Find("Universal Render Pipeline/Lit")
                    ?? Shader.Find("Standard"));
                r.material.color = new Color(0.42f, 0.32f, 0.2f);
            }

            // Subtle grid markers
            for (int i = -2; i <= 2; i++)
            {
                CreateMarker(root, new Vector3(i * 5f, 0.01f, 0f));
                CreateMarker(root, new Vector3(0f, 0.01f, i * 5f));
            }
        }

        static void CreateMarker(Transform root, Vector3 pos)
        {
            if (pos.sqrMagnitude < 0.01f) return;
            var m = GameObject.CreatePrimitive(PrimitiveType.Cube);
            m.name = "YardMarker";
            m.transform.SetParent(root, false);
            m.transform.position = pos;
            m.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
            var col = m.GetComponent<Collider>();
            if (col != null) Object.Destroy(col);
            var r = m.GetComponent<Renderer>();
            if (r != null)
            {
                r.material = new Material(Shader.Find("Universal Render Pipeline/Lit")
                    ?? Shader.Find("Standard"));
                r.material.color = new Color(0.35f, 0.28f, 0.18f);
            }
        }

        static Canvas CreateCanvas(Transform root)
        {
            var go = new GameObject("UICanvas");
            go.transform.SetParent(root, false);
            var canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;
            var scaler = go.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            go.AddComponent<GraphicRaycaster>();
            return canvas;
        }

        public static List<PartDefinition> CreateDemoPartDefinitions()
        {
            var list = new List<PartDefinition>();

            list.Add(PartDefinition.CreateRuntime(
                "Tank",
                PartType.Tank,
                new Vector3(1.2f, 1.4f, 1.2f),
                new Color(0.3f, 0.55f, 0.85f),
                100f, 100f, 0f,
                new PortDefinition("out", new Vector3(0f, 0f, -0.7f), PortDirection.Outlet)
                {
                    GizmoColor = Color.cyan
                }
            ));

            list.Add(PartDefinition.CreateRuntime(
                "Valve",
                PartType.Valve,
                new Vector3(0.6f, 0.6f, 0.6f),
                new Color(0.75f, 0.2f, 0.2f),
                0f, 0f, 0f,
                new PortDefinition("a", new Vector3(0f, 0f, -0.4f), PortDirection.Bidirectional) { GizmoColor = Color.cyan },
                new PortDefinition("b", new Vector3(0f, 0f, 0.4f), PortDirection.Bidirectional) { GizmoColor = Color.cyan }
            ));

            list.Add(PartDefinition.CreateRuntime(
                "Thruster",
                PartType.Thruster,
                new Vector3(0.7f, 1.0f, 0.7f),
                new Color(0.85f, 0.55f, 0.15f),
                0f, 0f, 12f,
                new PortDefinition("in", new Vector3(0f, 0.3f, 0.45f), PortDirection.Inlet) { GizmoColor = Color.cyan }
            ));

            list.Add(PartDefinition.CreateRuntime(
                "Vent",
                PartType.Vent,
                new Vector3(0.5f, 0.8f, 0.5f),
                new Color(0.5f, 0.7f, 0.5f),
                0f, 0f, 0f,
                new PortDefinition("in", new Vector3(0f, 0f, -0.35f), PortDirection.Inlet) { GizmoColor = Color.cyan }
            ));

            list.Add(PartDefinition.CreateRuntime(
                "Pipe",
                PartType.Pipe,
                new Vector3(0.35f, 0.35f, 1.2f),
                new Color(0.55f, 0.55f, 0.6f),
                0f, 0f, 0f,
                new PortDefinition("a", new Vector3(0f, 0f, -0.65f), PortDirection.Bidirectional) { GizmoColor = Color.cyan },
                new PortDefinition("b", new Vector3(0f, 0f, 0.65f), PortDirection.Bidirectional) { GizmoColor = Color.cyan }
            ));

            return list;
        }
    }
}
