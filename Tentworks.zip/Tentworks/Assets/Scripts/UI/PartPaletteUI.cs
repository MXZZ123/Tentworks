using System.Collections.Generic;
using Tentworks.Build;
using Tentworks.Parts;
using UnityEngine;
using UnityEngine.UI;

namespace Tentworks.UI
{
    /// <summary>Simple bottom-left palette buttons for part types.</summary>
    public class PartPaletteUI : MonoBehaviour
    {
        BuildController _build;
        readonly List<Button> _buttons = new List<Button>();

        public static PartPaletteUI Create(Transform canvasTransform, BuildController build)
        {
            var go = new GameObject("PartPaletteUI");
            go.transform.SetParent(canvasTransform, false);
            var ui = go.AddComponent<PartPaletteUI>();
            ui._build = build;
            ui.Build(canvasTransform as RectTransform);
            return ui;
        }

        void Build(RectTransform canvas)
        {
            var panel = new GameObject("PalettePanel");
            panel.transform.SetParent(canvas, false);
            var rt = panel.AddComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(0f, 0f);
            rt.pivot = new Vector2(0f, 0f);
            rt.anchoredPosition = new Vector2(16f, 80f);
            rt.sizeDelta = new Vector2(520f, 56f);

            var img = panel.AddComponent<Image>();
            img.color = new Color(0.1f, 0.1f, 0.12f, 0.7f);

            var layout = panel.AddComponent<HorizontalLayoutGroup>();
            layout.padding = new RectOffset(6, 6, 6, 6);
            layout.spacing = 6;
            layout.childAlignment = TextAnchor.MiddleLeft;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = true;

            if (_build == null) return;
            var palette = _build.Palette;
            for (int i = 0; i < palette.Count; i++)
            {
                int index = i;
                var def = palette[i];
                var btnGo = new GameObject($"Btn_{def.DisplayName}");
                btnGo.transform.SetParent(panel.transform, false);
                var btnImg = btnGo.AddComponent<Image>();
                btnImg.color = Color.Lerp(def.Color, Color.white, 0.25f);
                var btn = btnGo.AddComponent<Button>();
                btn.targetGraphic = btnImg;

                var labelGo = new GameObject("Label");
                labelGo.transform.SetParent(btnGo.transform, false);
                var lrt = labelGo.AddComponent<RectTransform>();
                lrt.anchorMin = Vector2.zero;
                lrt.anchorMax = Vector2.one;
                lrt.offsetMin = Vector2.zero;
                lrt.offsetMax = Vector2.zero;
                var text = labelGo.AddComponent<Text>();
                text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf")
                    ?? Resources.GetBuiltinResource<Font>("Arial.ttf");
                text.text = $"{i + 1} {def.DisplayName}";
                text.alignment = TextAnchor.MiddleCenter;
                text.color = Color.black;
                text.fontSize = 14;

                btn.onClick.AddListener(() => _build.SelectPaletteIndex(index));
                _buttons.Add(btn);
            }

            // Mode buttons
            AddModeButton(panel.transform, "Place(Q)", () => _build.SetMode(BuildMode.Place));
            AddModeButton(panel.transform, "Connect(E)", () => _build.SetMode(BuildMode.Connect));
            AddModeButton(panel.transform, "Valve(R)", () => _build.SetMode(BuildMode.Interact));
        }

        void AddModeButton(Transform parent, string label, UnityEngine.Events.UnityAction action)
        {
            var btnGo = new GameObject($"Mode_{label}");
            btnGo.transform.SetParent(parent, false);
            var btnImg = btnGo.AddComponent<Image>();
            btnImg.color = new Color(0.25f, 0.45f, 0.7f, 1f);
            var btn = btnGo.AddComponent<Button>();
            btn.targetGraphic = btnImg;
            btn.onClick.AddListener(action);

            var labelGo = new GameObject("Label");
            labelGo.transform.SetParent(btnGo.transform, false);
            var lrt = labelGo.AddComponent<RectTransform>();
            lrt.anchorMin = Vector2.zero;
            lrt.anchorMax = Vector2.one;
            lrt.offsetMin = Vector2.zero;
            lrt.offsetMax = Vector2.zero;
            var text = labelGo.AddComponent<Text>();
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf")
                ?? Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.text = label;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = Color.white;
            text.fontSize = 13;
        }

        void Update()
        {
            if (_build == null) return;
            // Could refresh selection highlight later
        }
    }
}
