using UnityEngine;
using UnityEngine.UI;

namespace Tentworks.UI
{
    /// <summary>On-screen hint / status text for beginners.</summary>
    public class HintUI : MonoBehaviour
    {
        Text _hintText;
        Text _modeText;
        Text _controlsText;

        public static HintUI Create(Transform canvasTransform)
        {
            var go = new GameObject("HintUI");
            go.transform.SetParent(canvasTransform, false);
            var ui = go.AddComponent<HintUI>();
            ui.Build(canvasTransform as RectTransform);
            return ui;
        }

        void Build(RectTransform canvas)
        {
            _hintText = MakeLabel(canvas, "HintText", new Vector2(0.5f, 0f), new Vector2(0.5f, 0f),
                new Vector2(0f, 24f), new Vector2(900f, 48f), 20, TextAnchor.MiddleCenter);

            _modeText = MakeLabel(canvas, "ModeText", new Vector2(0f, 1f), new Vector2(0f, 1f),
                new Vector2(16f, -16f), new Vector2(420f, 36f), 18, TextAnchor.UpperLeft);

            _controlsText = MakeLabel(canvas, "ControlsText", new Vector2(1f, 1f), new Vector2(1f, 1f),
                new Vector2(-16f, -16f), new Vector2(460f, 140f), 15, TextAnchor.UpperRight);
            _controlsText.text =
                "CONTROLS\n" +
                "1–5  Select part\n" +
                "Q Place · E Connect · R Interact\n" +
                "LMB Place / Connect / Toggle valve\n" +
                "RMB / Esc Cancel connect\n" +
                "Space Hold to fire thrusters\n" +
                "RMB drag Orbit · Scroll Zoom · MMB Pan";

            SetHint("Welcome to Tentworks (slice 1). Place a Tank, Valve, Thruster. Connect ports. Open valve. Hold Space.");
            SetMode("Mode: Place");
        }

        Text MakeLabel(RectTransform parent, string name, Vector2 anchorMin, Vector2 anchorMax,
            Vector2 anchoredPos, Vector2 size, int fontSize, TextAnchor align)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var rt = go.AddComponent<RectTransform>();
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.pivot = anchorMin.x < 0.5f ? new Vector2(0f, 1f) :
                       anchorMin.x > 0.5f ? new Vector2(1f, 1f) : new Vector2(0.5f, 0f);
            if (anchorMin.y > 0.5f && Mathf.Approximately(anchorMin.x, 0.5f) == false && anchorMin.x < 0.5f)
                rt.pivot = new Vector2(0f, 1f);
            if (anchorMin.x > 0.5f)
                rt.pivot = new Vector2(1f, 1f);
            if (Mathf.Approximately(anchorMin.x, 0.5f) && Mathf.Approximately(anchorMin.y, 0f))
                rt.pivot = new Vector2(0.5f, 0f);

            rt.anchoredPosition = anchoredPos;
            rt.sizeDelta = size;

            var text = go.AddComponent<Text>();
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (text.font == null)
                text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = fontSize;
            text.color = Color.white;
            text.alignment = align;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;

            // Shadow-ish background
            var bg = new GameObject(name + "_BG");
            bg.transform.SetParent(go.transform, false);
            bg.transform.SetAsFirstSibling();
            var bgRt = bg.AddComponent<RectTransform>();
            bgRt.anchorMin = Vector2.zero;
            bgRt.anchorMax = Vector2.one;
            bgRt.offsetMin = new Vector2(-8f, -4f);
            bgRt.offsetMax = new Vector2(8f, 4f);
            var img = bg.AddComponent<Image>();
            img.color = new Color(0f, 0f, 0f, 0.55f);

            return text;
        }

        public void SetHint(string msg)
        {
            if (_hintText != null) _hintText.text = msg ?? "";
        }

        public void SetMode(string msg)
        {
            if (_modeText != null) _modeText.text = msg ?? "";
        }
    }
}
