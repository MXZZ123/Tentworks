namespace Tentworks.Facilities
{
    /// <summary>Progression stages for Tentworks facilities (slice 1 = Tent only).</summary>
    public enum FacilityStage
    {
        Tent = 0,
        Workshop = 1,
        Bay = 2,
        Pad = 3,
        Factory = 4
    }
}
