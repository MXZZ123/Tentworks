using UnityEngine;

namespace Tentworks.Facilities
{
    /// <summary>Slice-1 stub: a basic tent (placeholder primitives) in the dirt yard.</summary>
    public class TentFacility : MonoBehaviour
    {
        public FacilityStage Stage => FacilityStage.Tent;

        public static TentFacility Spawn(Transform parent, Vector3 position)
        {
            var root = new GameObject("Tent");
            root.transform.SetParent(parent, false);
            root.transform.position = position;

            var tent = root.AddComponent<TentFacility>();
            tent.BuildPlaceholder();
            return tent;
        }

        void BuildPlaceholder()
        {
            // Floor mat
            var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            floor.name = "TentFloor";
            floor.transform.SetParent(transform, false);
            floor.transform.localPosition = new Vector3(0f, 0.02f, 0f);
            floor.transform.localScale = new Vector3(4f, 0.05f, 3f);
            SetColor(floor, new Color(0.45f, 0.32f, 0.18f));

            // Canvas walls (four thin boxes)
            CreateWall("WallN", new Vector3(0f, 1f, 1.5f), new Vector3(4f, 2f, 0.08f));
            CreateWall("WallS", new Vector3(0f, 1f, -1.5f), new Vector3(4f, 2f, 0.08f));
            CreateWall("WallE", new Vector3(2f, 1f, 0f), new Vector3(0.08f, 2f, 3f));
            // Open doorway on west
            CreateWall("WallW_L", new Vector3(-2f, 1f, 0.9f), new Vector3(0.08f, 2f, 1.2f));
            CreateWall("WallW_R", new Vector3(-2f, 1f, -0.9f), new Vector3(0.08f, 2f, 1.2f));

            // Simple pitched roof (two slabs)
            var roofL = GameObject.CreatePrimitive(PrimitiveType.Cube);
            roofL.name = "RoofL";
            roofL.transform.SetParent(transform, false);
            roofL.transform.localPosition = new Vector3(0f, 2.2f, 0.55f);
            roofL.transform.localRotation = Quaternion.Euler(25f, 0f, 0f);
            roofL.transform.localScale = new Vector3(4.2f, 0.08f, 1.8f);
            SetColor(roofL, new Color(0.75f, 0.55f, 0.25f));

            var roofR = GameObject.CreatePrimitive(PrimitiveType.Cube);
            roofR.name = "RoofR";
            roofR.transform.SetParent(transform, false);
            roofR.transform.localPosition = new Vector3(0f, 2.2f, -0.55f);
            roofR.transform.localRotation = Quaternion.Euler(-25f, 0f, 0f);
            roofR.transform.localScale = new Vector3(4.2f, 0.08f, 1.8f);
            SetColor(roofR, new Color(0.75f, 0.55f, 0.25f));

            // Pole
            var pole = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pole.name = "CenterPole";
            pole.transform.SetParent(transform, false);
            pole.transform.localPosition = new Vector3(0f, 1.2f, 0f);
            pole.transform.localScale = new Vector3(0.12f, 1.2f, 0.12f);
            SetColor(pole, new Color(0.35f, 0.25f, 0.15f));
        }

        void CreateWall(string name, Vector3 localPos, Vector3 scale)
        {
            var w = GameObject.CreatePrimitive(PrimitiveType.Cube);
            w.name = name;
            w.transform.SetParent(transform, false);
            w.transform.localPosition = localPos;
            w.transform.localScale = scale;
            SetColor(w, new Color(0.82f, 0.72f, 0.45f));
        }

        static void SetColor(GameObject go, Color c)
        {
            var r = go.GetComponent<Renderer>();
            if (r == null) return;
            r.material = new Material(Shader.Find("Universal Render Pipeline/Lit")
                ?? Shader.Find("Standard"));
            r.material.color = c;
        }
    }
}
