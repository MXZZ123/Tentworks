using UnityEngine;

namespace Tentworks.Parts
{
    /// <summary>Runtime propellant port attached to a placed PartInstance.</summary>
    public class Port : MonoBehaviour
    {
        public string PortId;
        public PortDirection Direction;
        public PartInstance Owner;
        public Port ConnectedTo;

        public Vector3 WorldPosition => transform.position;

        public bool IsConnected => ConnectedTo != null;

        public void Connect(Port other)
        {
            if (other == null || other == this) return;
            ConnectedTo = other;
            other.ConnectedTo = this;
        }

        public void Disconnect()
        {
            if (ConnectedTo != null)
            {
                var other = ConnectedTo;
                ConnectedTo = null;
                other.ConnectedTo = null;
            }
        }

        public void Configure(string id, PortDirection direction, PartInstance owner)
        {
            PortId = id;
            Direction = direction;
            Owner = owner;
            gameObject.name = $"Port_{id}";
            tag = "Port";
        }
    }
}
