using System;
using UnityEngine;

namespace Tentworks.Parts
{
    /// <summary>Describes a propellant port on a part definition (local offset + direction).</summary>
    [Serializable]
    public class PortDefinition
    {
        public string Id = "port";
        public Vector3 LocalOffset = Vector3.zero;
        public PortDirection Direction = PortDirection.Bidirectional;
        public Color GizmoColor = Color.cyan;

        public PortDefinition() { }

        public PortDefinition(string id, Vector3 localOffset, PortDirection direction)
        {
            Id = id;
            LocalOffset = localOffset;
            Direction = direction;
        }
    }
}
