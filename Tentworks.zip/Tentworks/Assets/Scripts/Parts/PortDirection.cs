namespace Tentworks.Parts
{
    /// <summary>Whether a port can send, receive, or both (propellant).</summary>
    public enum PortDirection
    {
        Bidirectional,
        Outlet,
        Inlet
    }
}
