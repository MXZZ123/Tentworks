namespace Tentworks.Parts
{
    /// <summary>Kinds of placeable rocket-engineering parts in slice 1.</summary>
    public enum PartType
    {
        Tank,
        Valve,
        Thruster,
        Vent,
        Pipe
    }
}
