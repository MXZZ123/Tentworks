using System.Collections.Generic;
using UnityEngine;

namespace Tentworks.Parts
{
    /// <summary>
    /// ScriptableObject describing a placeable part: type, size, ports, and default fluid capacity.
    /// Created at runtime by GameBootstrap for slice 1 (no .asset files required).
    /// </summary>
    [CreateAssetMenu(fileName = "PartDefinition", menuName = "Tentworks/Part Definition", order = 0)]
    public class PartDefinition : ScriptableObject
    {
        public string DisplayName = "Part";
        public PartType Type = PartType.Tank;
        public Vector3 Size = Vector3.one;
        public Color Color = Color.gray;
        public float DefaultMassKg = 100f;
        public float MaxMassKg = 100f;
        public float BurnRateKgPerSec = 0f;
        public List<PortDefinition> Ports = new List<PortDefinition>();

        public static PartDefinition CreateRuntime(
            string displayName,
            PartType type,
            Vector3 size,
            Color color,
            float defaultMass,
            float maxMass,
            float burnRate,
            params PortDefinition[] ports)
        {
            var def = CreateInstance<PartDefinition>();
            def.name = displayName;
            def.DisplayName = displayName;
            def.Type = type;
            def.Size = size;
            def.Color = color;
            def.DefaultMassKg = defaultMass;
            def.MaxMassKg = maxMass;
            def.BurnRateKgPerSec = burnRate;
            def.Ports = new List<PortDefinition>(ports);
            return def;
        }
    }
}
