using System.Collections.Generic;
using UnityEngine;

namespace Tentworks.Parts
{
    /// <summary>A placed part in the yard: holds definition, mass, valve state, and ports.</summary>
    public class PartInstance : MonoBehaviour
    {
        public PartDefinition Definition;
        public float CurrentMassKg;
        public bool ValveOpen = true;
        public List<Port> Ports = new List<Port>();

        Renderer _bodyRenderer;
        GameObject _thrustVisual;

        public PartType Type => Definition != null ? Definition.Type : PartType.Pipe;
        public bool IsValve => Type == PartType.Valve;
        public bool IsThruster => Type == PartType.Thruster;
        public bool IsTank => Type == PartType.Tank;
        public bool IsVent => Type == PartType.Vent;

        public void Initialize(PartDefinition def)
        {
            Definition = def;
            CurrentMassKg = def.DefaultMassKg;
            ValveOpen = def.Type != PartType.Valve; // valves start closed for teaching
            if (def.Type == PartType.Valve)
                ValveOpen = false;

            BuildVisuals();
            BuildPorts();
            UpdateValveVisual();
        }

        void BuildVisuals()
        {
            var body = GameObject.CreatePrimitive(PrimitiveType.Cube);
            body.name = "Body";
            body.transform.SetParent(transform, false);
            body.transform.localScale = Definition.Size;
            body.transform.localPosition = Vector3.zero;

            // Remove collider from child; parent gets a box for placement picking
            var childCol = body.GetComponent<Collider>();
            if (childCol != null) Destroy(childCol);

            _bodyRenderer = body.GetComponent<Renderer>();
            if (_bodyRenderer != null)
            {
                _bodyRenderer.material = new Material(Shader.Find("Universal Render Pipeline/Lit")
                    ?? Shader.Find("Standard"));
                _bodyRenderer.material.color = Definition.Color;
            }

            var box = gameObject.GetComponent<BoxCollider>();
            if (box == null) box = gameObject.AddComponent<BoxCollider>();
            box.size = Definition.Size;
            box.center = Vector3.zero;

            tag = "Part";

            if (Definition.Type == PartType.Thruster)
            {
                _thrustVisual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                _thrustVisual.name = "ThrustFlame";
                _thrustVisual.transform.SetParent(transform, false);
                _thrustVisual.transform.localPosition = new Vector3(0f, -Definition.Size.y * 0.5f - 0.4f, 0f);
                _thrustVisual.transform.localRotation = Quaternion.identity;
                _thrustVisual.transform.localScale = new Vector3(0.35f, 0.8f, 0.35f);
                var col = _thrustVisual.GetComponent<Collider>();
                if (col != null) Destroy(col);
                var r = _thrustVisual.GetComponent<Renderer>();
                if (r != null)
                {
                    r.material = new Material(Shader.Find("Universal Render Pipeline/Unlit")
                        ?? Shader.Find("Unlit/Color")
                        ?? Shader.Find("Standard"));
                    r.material.color = new Color(1f, 0.45f, 0.05f, 1f);
                }
                _thrustVisual.SetActive(false);
            }
        }

        void BuildPorts()
        {
            Ports.Clear();
            if (Definition.Ports == null) return;

            foreach (var pd in Definition.Ports)
            {
                var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                go.transform.SetParent(transform, false);
                go.transform.localPosition = pd.LocalOffset;
                go.transform.localScale = Vector3.one * 0.22f;

                var col = go.GetComponent<Collider>();
                if (col != null)
                {
                    // Keep collider for clicking ports
                    col.isTrigger = true;
                }

                var r = go.GetComponent<Renderer>();
                if (r != null)
                {
                    r.material = new Material(Shader.Find("Universal Render Pipeline/Lit")
                        ?? Shader.Find("Standard"));
                    r.material.color = pd.GizmoColor;
                }

                var port = go.AddComponent<Port>();
                port.Configure(pd.Id, pd.Direction, this);
                Ports.Add(port);
            }
        }

        public void ToggleValve()
        {
            if (!IsValve) return;
            ValveOpen = !ValveOpen;
            UpdateValveVisual();
        }

        public void SetValve(bool open)
        {
            if (!IsValve) return;
            ValveOpen = open;
            UpdateValveVisual();
        }

        void UpdateValveVisual()
        {
            if (!IsValve || _bodyRenderer == null) return;
            _bodyRenderer.material.color = ValveOpen
                ? Color.Lerp(Definition.Color, Color.green, 0.5f)
                : Color.Lerp(Definition.Color, Color.red, 0.45f);
        }

        public void SetThrustVisual(bool on)
        {
            if (_thrustVisual != null)
                _thrustVisual.SetActive(on);
        }

        public Port GetPort(string id)
        {
            foreach (var p in Ports)
                if (p.PortId == id) return p;
            return Ports.Count > 0 ? Ports[0] : null;
        }
    }
}
