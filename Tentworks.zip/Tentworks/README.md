# Tentworks — Slice 1 (Scaffold)

**Tentworks** is a rocket-engineer simulation game. This repository is **slice 1 only**: a dirt yard, a basic tent, and a toy propellant loop (tank → valve → thruster) built from placeholder primitives.

Designed so a Unity beginner (Morgan) can copy the folder to Windows, open it in **Unity Hub**, and press Play.

---

## Requirements

| Item | Recommendation |
|------|----------------|
| Editor | **Unity 6000.0** (Unity 6) — matches `ProjectSettings/ProjectVersion.txt` |
| Render pipeline | URP (`com.unity.render-pipelines.universal` in `Packages/manifest.json`) |
| Fallback | **2022.3 LTS** may work with small tweaks (shader names / package versions). Prefer Unity 6. |
| OS for play | Windows (this scaffold was authored on Linux; no Editor run required here) |

No paid assets. Placeholder primitives only.

---

## Open in Unity Hub (Windows) — exact steps

1. **Install Unity Hub** from [https://unity.com/download](https://unity.com/download) if you do not have it.
2. In Hub → **Installs**, install **Unity 6000.0.x** (any 6000.0 patch). Include **Windows Build Support** if offered.
3. Copy the entire `Tentworks` folder to your PC (e.g. `C:\Users\<you>\Projects\Tentworks`).  
   - If you received `Tentworks.zip`, unzip it first.  
   - Do **not** need a `Library/` folder — Unity creates it on first open.
4. Hub → **Projects** → **Open** → select the `Tentworks` folder (the one that contains `Assets`, `Packages`, `ProjectSettings`).
5. Wait for the first import (URP packages download; can take several minutes).
6. If prompted about **Input System** / **Active Input Handling**, choose **Both** (or keep Old). This project uses the classic `Input` API.
7. If the **URP** wizard or render-pipeline asset popup appears, accept defaults / create a URP asset if Unity asks. Slice 1 also falls back to `Standard` shaders if URP Lit is missing.
8. Open the scene: **Assets → Scenes → Bootstrap**.
9. Press **Play** (▶).

### If Bootstrap scene has a missing script

1. Create a new empty scene (**File → New Scene** → Basic).
2. Create an empty GameObject (**GameObject → Create Empty**), name it `GameBootstrap`.
3. **Add Component** → search `GameBootstrap` → add it.
4. Press **Play**. The script builds the yard, tent, lighting, UI, and controllers at runtime.

Add `Assets/Scenes/Bootstrap` (or your new scene) to **File → Build Settings** if you want it as the startup scene.

---

## How to play (slice 1)

**Goal:** Place a **Tank**, **Valve**, and **Thruster**, connect their cyan port spheres, open the valve, hold **Space** to fire. The thruster shows a flame and the tank mass depletes.

### Controls

| Input | Action |
|-------|--------|
| **1–5** | Select part (Tank, Valve, Thruster, Vent, Pipe) |
| **Q** | Place mode |
| **E** | Connect mode (click port A, then port B) |
| **R** | Interact mode (click valve to open/close) |
| **LMB** | Place on dirt / select ports / toggle valve |
| **RMB** | Orbit camera (drag) · cancel pending connect |
| **MMB** | Pan camera (drag) |
| **Scroll** | Zoom |
| **Space** (hold) | Fire thrusters if an open fueled path exists |
| **Esc** | Cancel connect |

Valves start **closed** (redder). Open them in Interact mode (they turn greener) before firing.

### Suggested first run

1. Press **1**, click the dirt → place **Tank**.
2. Press **2**, place **Valve** nearby.
3. Press **3**, place **Thruster**.
4. Press **E**, click Tank’s cyan port, then Valve’s near port; then Valve’s other port → Thruster’s port.
5. Press **R**, click the Valve to **open** it.
6. Hold **Space** → orange thrust capsule + tank mass drops (see on-screen hint).

---

## Project layout (short)

```
Tentworks/
  Assets/
    Scenes/Bootstrap.unity   ← open this
    Scripts/
      GameBootstrap.cs       ← runtime world builder
      Parts/ Fluid/ Build/ Simulation/ Facilities/ UI/
  Packages/manifest.json     ← Unity 6 + URP
  ProjectSettings/
  docs/VISION.md
  docs/ARCHITECTURE.md
  README.md
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the folder map and [docs/VISION.md](docs/VISION.md) for the full game vision.

---

## Out of scope (slice 1)

Factories, launch bays/pads, fancy art, multiplayer, real chemistry / thermodynamics.

---

## License / assets

Scaffold and scripts are project-local. No third-party paid packages.
