# Tentworks — Architecture (slice 1)

## Folder map

```
Tentworks/
├── Assets/
│   ├── Scenes/
│   │   └── Bootstrap.unity          # Empty scene + GameBootstrap component
│   ├── Scripts/
│   │   ├── GameBootstrap.cs         # Builds yard/tent/light/UI/controllers at Play
│   │   ├── Parts/
│   │   │   ├── PartType.cs
│   │   │   ├── PortDirection.cs
│   │   │   ├── PortDefinition.cs
│   │   │   ├── PartDefinition.cs    # ScriptableObject (+ runtime CreateRuntime)
│   │   │   ├── Port.cs              # Runtime port MonoBehaviour
│   │   │   └── PartInstance.cs      # Placed part + visuals + valve/thrust
│   │   ├── Fluid/
│   │   │   ├── FluidNode.cs
│   │   │   ├── FluidEdge.cs
│   │   │   └── FluidGraph.cs        # Connect + BFS open path Tank→Valve→Thruster
│   │   ├── Build/
│   │   │   ├── BuildMode.cs
│   │   │   ├── BuildController.cs   # Place / connect / interact
│   │   │   └── OrbitCamera.cs
│   │   ├── Simulation/
│   │   │   └── SimulationTicker.cs  # Space = fire + deplete mass
│   │   ├── Facilities/
│   │   │   ├── FacilityStage.cs     # Tent…Factory enum
│   │   │   └── TentFacility.cs      # Placeholder tent
│   │   └── UI/
│   │       ├── HintUI.cs
│   │       └── PartPaletteUI.cs
│   └── Settings/                    # Reserved for URP assets (Editor may fill)
├── Packages/
│   └── manifest.json                # Unity 6 + URP
├── ProjectSettings/                 # Hub-recognisable project
└── docs/
    ├── VISION.md
    └── ARCHITECTURE.md
```

## Runtime flow

1. Scene loads → `GameBootstrap.Start` → `Bootstrap()`.
2. Creates `TentworksRoot`: dirt plane, tent, sun, orbit camera, EventSystem, Canvas.
3. Builds demo `PartDefinition` list in memory (no `.asset` files required).
4. `BuildController` handles place/connect/interact; owns a `FluidGraph`.
5. `SimulationTicker` each frame: if Space held, query graph for open paths; deplete tank; enable thruster visual.

## Key types

| Type | Namespace | Role |
|------|-----------|------|
| `PartDefinition` | `Tentworks.Parts` | Data for a placeable part + ports |
| `PartInstance` / `Port` | `Tentworks.Parts` | Scene instances |
| `FluidGraph` | `Tentworks.Fluid` | Nodes/edges + path query |
| `BuildController` | `Tentworks.Build` | Input + placement |
| `SimulationTicker` | `Tentworks.Simulation` | Burn / deplete |
| `FacilityStage` / `TentFacility` | `Tentworks.Facilities` | Stage enum + tent stub |
| `HintUI` / `PartPaletteUI` | `Tentworks.UI` | Beginner HUD |

## Extension notes

- New parts: add to `GameBootstrap.CreateDemoPartDefinitions()` or author `PartDefinition` assets via **Create → Tentworks → Part Definition**.
- New facilities: implement beside `TentFacility`, gate with `FacilityStage`.
- Do not put factories/bays/pads logic in slice 1 controllers — keep stubs in `Facilities`.
