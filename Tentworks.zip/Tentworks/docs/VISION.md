# Tentworks — Vision

## Pitch

You are a rocket engineer starting from almost nothing: a **dirt yard** and a **tent**. You scrounge, place, and plumb propellant hardware, learn flow and failure modes, and grow facilities until you can assemble and fire real vehicles.

Tone: grounded engineering toy — readable systems, not hard-sci-fi chemistry.

## Full arc (future)

| Stage | Facility | Player fantasy |
|-------|----------|----------------|
| 0–1 | **Tent** + yard | Place tanks/valves/thrusters; connect ports; fire a tiny loop |
| 2 | **Workshop** | Benches, basic fab, inventory of parts |
| 3 | **Bay** | Vehicle frames, staging, umbilical mockups |
| 4 | **Pad** | Static fires, range safety, telemetry |
| 5 | **Factory** | Production lines, quality, logistics |

## Slice roadmap (high level)

- **Slice 1 (this repo):** Yard + tent stub, part palette, port connect, valve toggle, thrust + mass deplete, orbit camera, on-screen hints. Primitives only.
- **Slice 2:** Save/load layouts, better pipe visuals, simple leak/vent behaviour, part mass UI.
- **Slice 3:** Workshop facility unlock, crafting recipes (still abstract), camera bookmarks.
- **Slice 4+:** Bay/pad, vehicle assembly graph, soft failure modes, polish art pass.

## Design principles

1. **Readable plumbing** — ports and valves should be obvious to a beginner.
2. **Runtime-friendly** — prefer bootstrap / data-driven defs over fragile hand-authored scenes early on.
3. **No paid asset dependency** for core loop.
4. **Namespaces stay stable** (`Tentworks.Parts`, `.Fluid`, `.Build`, `.Simulation`, `.Facilities`, `.UI`) as slices grow.
